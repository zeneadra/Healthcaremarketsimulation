package healthcaresimulationpackage;

public interface Deepcopiableactor {
	public Actor deepcopyagent();

}
